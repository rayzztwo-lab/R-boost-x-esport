package com.gameturbo.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import kotlin.math.abs

/**
 * Floating window: garis abu-abu di tepi layar. Ketuk / geser ke dalam -> panel R BOOST
 * (halaman panel.html) meluncur keluar dari tepi. Garis hanya muncul di atas game.
 */
class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { Games.prefs(this) }

    private var handle: FrameLayout? = null
    private var line: View? = null
    private lateinit var lpHandle: WindowManager.LayoutParams
    private var panel: WebView? = null
    private var lpPanel: WindowManager.LayoutParams? = null
    private var mini: TextView? = null
    private var intro: WebView? = null
    private var lastIntro = 0L
    private var lastGame: String? = null
    private var previewIntro = false
    private var lpMini: WindowManager.LayoutParams? = null

    private var gamePkg: String? = null
    private var gameSet: Set<String> = emptySet()
    private var gameSetAt = 0L
    private var rightSide = true
    private var pmode = "bal"
    private var keepOn = false
    private var dndOn = false
    private var prevFilter = -1
    private var lastAuto = 0L
    private var cross: View? = null
    private var xDndSet = false

    @Volatile
    private var fps = 0
    private var frames = 0
    private var lastMs = 0L
    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            val now = frameTimeNanos / 1_000_000L
            if (lastMs == 0L) lastMs = now
            frames++
            val dt = now - lastMs
            if (dt >= 1000L) {
                fps = (frames * 1000L / dt).toInt()
                frames = 0
                lastMs = now
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            detectForeground()
            updateMini()
            pmode = prefs.getString("pmode", pmode) ?: pmode
            if (prefs.getBoolean("xmode", false) && prefs.getBoolean("x_dnd", false) && gamePkg != null && !xDndSet) {
                xDndSet = true; setDnd(true)
            }
            val nowMs = System.currentTimeMillis()
            if (pmode == "adv" && gamePkg != null && nowMs - lastAuto > 180_000L) {
                lastAuto = nowMs
                Thread { Booster.boost(this@OverlayService, setOfNotNull(gamePkg)) }.start()
            }
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        rightSide = prefs.getString("side", "right") == "right"
        pmode = prefs.getString("pmode", "bal") ?: "bal"
        keepOn = pmode != "bal"
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_MINI -> {
                toggleMini()
                return START_STICKY
            }
            ACTION_INTRO -> previewIntro = true
        }
        val launched = intent?.getStringExtra(EXTRA_GAME)
        if (launched != null) gamePkg = launched
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        val want = prefs.getString("side", "right") == "right"
        if (handle != null && want != rightSide) {
            rightSide = want
            handle?.let { try { wm.removeView(it) } catch (_: Exception) {} }
            handle = null
        }
        if (handle == null) {
            buildHandle()
            handler.removeCallbacks(tick)
            handler.post(tick)
        }
        if (previewIntro) {
            previewIntro = false
            lastIntro = 0L
            showIntro()
        } else if (launched != null) {
            handler.postDelayed({ showIntro() }, 1500L)
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacks(tick)
        Choreographer.getInstance().removeFrameCallback(frameCb)
        removePanel()
        removeMini()
        removeIntro()
        removeCross()
        handle?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        handle = null
        if (dndOn) setDnd(false)
        super.onDestroy()
    }

    // ---------- util ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    @Suppress("DEPRECATION")
    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    private fun baseFlags(): Int {
        var f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
        if (keepOn) f = f or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        return f
    }

    private fun sideGravity(): Int = Gravity.TOP or (if (rightSide) Gravity.END else Gravity.START)

    private fun toast(s: String) = Toast.makeText(applicationContext, s, Toast.LENGTH_SHORT).show()

    private fun openActivity(i: Intent) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) {
            toast("Tidak bisa dibuka dari sini")
        }
    }

    private fun nm() = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    private fun startAsForeground() {
        val channelId = "turbo"
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(channelId, "R BOOST", NotificationManager.IMPORTANCE_LOW)
            nm().createNotificationChannel(ch)
        }
        val stop = PendingIntent.getService(
            this, 0, Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("R BOOST aktif")
            .setContentText("Garis panel ada di tepi layar saat main game")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(0, "Matikan", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ---------- garis di tepi layar ----------

    private fun lineParams(): FrameLayout.LayoutParams = FrameLayout.LayoutParams(
        dp(7), dp(120), Gravity.CENTER_VERTICAL or (if (rightSide) Gravity.END else Gravity.START)
    )

    private fun lineDrawable(): GradientDrawable {
        val r = dp(5).toFloat()
        return GradientDrawable().apply {
            setColor(Color.parseColor("#E0D3D3D3"))
            cornerRadii = if (rightSide) floatArrayOf(r, r, 0f, 0f, 0f, 0f, r, r) else floatArrayOf(0f, 0f, r, r, r, r, 0f, 0f)
        }
    }

    private fun buildHandle() {
        val box = FrameLayout(this)
        val l = View(this)
        l.background = lineDrawable()
        box.addView(l, lineParams())
        line = l

        lpHandle = WindowManager.LayoutParams(
            dp(24), dp(132), overlayType(), baseFlags(), PixelFormat.TRANSLUCENT
        ).apply {
            gravity = sideGravity()
            x = 0
            y = prefs.getInt("hy", dp(120))
        }

        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var startY = 0
        var dragging = false
        var opened = false
        box.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startY = lpHandle.y
                    dragging = false; opened = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    val inward = if (rightSide) -dx else dx
                    if (!opened && !dragging && inward > dp(16) && abs(dx) > abs(dy)) {
                        opened = true
                        expand()
                    } else if (!opened && (dragging || (abs(dy) > slop && abs(dy) > abs(dx)))) {
                        dragging = true
                        val maxY = (Sys.realSize(this).second - dp(132)).coerceAtLeast(0)
                        lpHandle.y = (startY + dy).toInt().coerceIn(0, maxY)
                        try { wm.updateViewLayout(box, lpHandle) } catch (_: Exception) {}
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (opened) {
                        // sudah dibuka lewat geseran
                    } else if (dragging) {
                        prefs.edit().putInt("hy", lpHandle.y).apply()
                    } else {
                        expand()
                    }
                }
            }
            true
        }
        handle = box
        wm.addView(box, lpHandle)
    }

    private fun applyKeepOn() {
        try {
            handle?.let { lpHandle.flags = baseFlags(); wm.updateViewLayout(it, lpHandle) }
            val p = panel
            val lp = lpPanel
            if (p != null && lp != null) { lp.flags = baseFlags(); wm.updateViewLayout(p, lp) }
            val m = mini
            val lm = lpMini
            if (m != null && lm != null) { lm.flags = baseFlags(); wm.updateViewLayout(m, lm) }
        } catch (_: Exception) {}
    }

    // ---------- deteksi game di depan ----------

    private fun hasUsage(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager
        @Suppress("DEPRECATION")
        val m = ops.checkOpNoThrow(android.app.AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName)
        return m == android.app.AppOpsManager.MODE_ALLOWED
    }

    @Suppress("DEPRECATION")
    private fun foregroundPkg(): String? {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val ev = usm.queryEvents(now - 15000L, now)
        val e = UsageEvents.Event()
        var last: String? = null
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) last = e.packageName
        }
        return last
    }

    private fun showOverlays(show: Boolean) {
        val v = if (show) View.VISIBLE else View.GONE
        val h = handle
        if (h != null && panel == null && h.visibility != v) h.visibility = v
        val m = mini
        if (m != null && m.visibility != v) m.visibility = v
    }

    private fun detectForeground() {
        if (!prefs.getBoolean("auto", true) || !hasUsage()) {
            showOverlays(true)
            return
        }
        val fg = foregroundPkg() ?: return
        val nowMs = System.currentTimeMillis()
        if (nowMs - gameSetAt > 30000L) {
            gameSet = Games.gamePackages(this); gameSetAt = nowMs
        }
        if (fg in gameSet) {
            gamePkg = fg
            showOverlays(true)
            if (fg != lastGame) {
                lastGame = fg
                showIntro()
            }
        } else {
            lastGame = null
            if (xDndSet) { xDndSet = false; setDnd(false) }
            if (panel != null) collapse()
            showOverlays(false)
        }
    }

    // ---------- panel (WebView) ----------

    private fun updateFrameCb() {
        Choreographer.getInstance().removeFrameCallback(frameCb)
        if (panel != null || mini != null) {
            lastMs = 0L; frames = 0
            Choreographer.getInstance().postFrameCallback(frameCb)
        }
    }

    private fun expand() {
        if (panel != null) return
        val w = WebView(applicationContext)
        w.setBackgroundColor(Color.TRANSPARENT)
        w.overScrollMode = View.OVER_SCROLL_NEVER
        w.isVerticalScrollBarEnabled = false
        w.isHorizontalScrollBarEnabled = false
        w.settings.javaScriptEnabled = true
        w.addJavascriptInterface(PanelBridge(), "AP")
        val xm = prefs.getBoolean("xmode", false)
        w.loadUrl(if (xm) "file:///android_asset/panelx.html" else "file:///android_asset/panel.html?side=" + (if (rightSide) "r" else "l"))
        val sz = Sys.realSize(this)
        val sh = if (sz.first < sz.second) sz.first else sz.second
        val sw = if (sz.first < sz.second) sz.second else sz.first
        val panelH = (sh * 0.92f).toInt()
        val winW = if (xm) sw else (panelH * 1.06f).toInt() + dp(18)
        val lp = WindowManager.LayoutParams(
            winW, sh,
            overlayType(),
            baseFlags() or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = if (xm) Gravity.TOP or Gravity.START else Gravity.TOP or (if (rightSide) Gravity.END else Gravity.START)
        lp.x = 0
        lp.y = 0
        w.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_OUTSIDE) collapse()
            false
        }
        try {
            wm.addView(w, lp)
        } catch (e: Exception) {
            w.destroy()
            toast("Panel gagal dibuka")
            return
        }
        panel = w
        lpPanel = lp
        handle?.visibility = View.GONE
        updateFrameCb()
    }

    private fun collapse() {
        val p = panel ?: return
        p.evaluateJavascript("window.rbClose&&window.rbClose()", null)
        handler.postDelayed({ removePanel() }, 320L)
    }

    private fun removePanel() {
        val p = panel ?: return
        panel = null
        lpPanel = null
        try { wm.removeView(p) } catch (_: Exception) {}
        try { p.destroy() } catch (_: Exception) {}
        handle?.visibility = View.VISIBLE
        updateFrameCb()
    }

    // ---------- mini intro (kartu kecil saat masuk game) ----------

    private fun showIntro() {
        if (!prefs.getBoolean("intro", true)) return
        val now = System.currentTimeMillis()
        if (now - lastIntro < 10_000L || intro != null) return
        if (!Settings.canDrawOverlays(this)) return
        lastIntro = now
        val w = WebView(applicationContext)
        w.setBackgroundColor(Color.TRANSPARENT)
        w.overScrollMode = View.OVER_SCROLL_NEVER
        w.isVerticalScrollBarEnabled = false
        w.settings.javaScriptEnabled = true
        w.settings.mediaPlaybackRequiresUserGesture = false
        w.loadUrl("file:///android_asset/intro.html?m=" + pmode)
        val sz = Sys.realSize(this)
        val sh = if (sz.first < sz.second) sz.first else sz.second
        val h = (sh * 0.62f).toInt().coerceAtMost(dp(250))
        val lp = WindowManager.LayoutParams(
            (h * 0.86f).toInt(), h, overlayType(),
            baseFlags() or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(10)
        lp.y = dp(12)
        try {
            wm.addView(w, lp)
        } catch (e: Exception) {
            w.destroy()
            return
        }
        intro = w
        handler.postDelayed({ intro?.evaluateJavascript("window.rbOut&&window.rbOut()", null) }, 4700L)
        handler.postDelayed({ removeIntro() }, 5200L)
    }

    private fun removeIntro() {
        val w = intro ?: return
        intro = null
        try { wm.removeView(w) } catch (_: Exception) {}
        try { w.destroy() } catch (_: Exception) {}
    }

    // ---------- mini monitor (WM) ----------

    private fun toggleMini() {
        if (mini != null) {
            removeMini()
            return
        }
        val tv = TextView(this)
        tv.textSize = 11f
        tv.setTextColor(Color.WHITE)
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.setPadding(dp(10), dp(5), dp(10), dp(5))
        tv.background = GradientDrawable().apply {
            setColor(Color.parseColor("#CC0A0A0E"))
            cornerRadius = dp(10).toFloat()
            setStroke(dp(1), Color.parseColor("#99FF2020"))
        }
        tv.text = "R BOOST"
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(), baseFlags(), PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(16)
        lp.y = dp(10)
        var dx = 0f
        var dy = 0f
        var sx = 0
        var sy = 0
        tv.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = (sx + (e.rawX - dx)).toInt().coerceAtLeast(0)
                    lp.y = (sy + (e.rawY - dy)).toInt().coerceAtLeast(0)
                    try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
                }
            }
            true
        }
        try {
            wm.addView(tv, lp)
        } catch (e: Exception) {
            return
        }
        mini = tv
        lpMini = lp
        updateFrameCb()
    }

    private fun removeMini() {
        val m = mini ?: return
        mini = null
        lpMini = null
        try { wm.removeView(m) } catch (_: Exception) {}
        updateFrameCb()
    }

    private fun updateMini() {
        val m = mini ?: return
        val cpu = Sys.cpuPct()
        val sb = StringBuilder("FPS ").append(fps)
        if (cpu >= 0) sb.append("  CPU ").append(cpu).append("%")
        sb.append("  RAM ").append(Booster.ramPercent(this)).append("%")
        Booster.batteryTempC(this)?.let { sb.append("  ").append(it.toInt()).append("°C") }
        m.text = sb.toString()
    }

    // ---------- crosshair ----------

    private fun showCross() {
        if (cross != null) return
        val v = object : View(this) {
            override fun onDraw(c: android.graphics.Canvas) {
                val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
                p.color = Color.parseColor("#FF2A3A")
                p.strokeWidth = dp(2).toFloat()
                val cx = width / 2f
                val cy = height / 2f
                val g = dp(4).toFloat()
                val l = dp(10).toFloat()
                c.drawLine(cx - g - l, cy, cx - g, cy, p)
                c.drawLine(cx + g, cy, cx + g + l, cy, p)
                c.drawLine(cx, cy - g - l, cx, cy - g, p)
                c.drawLine(cx, cy + g, cx, cy + g + l, p)
                p.style = android.graphics.Paint.Style.FILL
                c.drawCircle(cx, cy, dp(1).toFloat() + 0.5f, p)
            }
        }
        val lp = WindowManager.LayoutParams(
            dp(60), dp(60), overlayType(),
            baseFlags() or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.CENTER
        try {
            wm.addView(v, lp)
            cross = v
        } catch (_: Exception) {
        }
    }

    private fun removeCross() {
        val v = cross ?: return
        cross = null
        try { wm.removeView(v) } catch (_: Exception) {}
    }

    // ---------- aksi panel ----------

    private fun setDnd(on: Boolean) {
        val n = nm()
        if (!n.isNotificationPolicyAccessGranted) return
        if (on) {
            if (prevFilter == -1) prevFilter = n.currentInterruptionFilter
            n.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
        } else if (prevFilter >= 1) {
            n.setInterruptionFilter(prevFilter); prevFilter = -1
        }
        dndOn = on
    }

    private fun setPMode(m: String) {
        pmode = m
        prefs.edit().putString("pmode", m).apply()
        keepOn = m != "bal"
        applyKeepOn()
        lastAuto = System.currentTimeMillis()
        if (m == "perf") Thread { Booster.boost(this, setOfNotNull(gamePkg)) }.start()
    }

    private fun togglePref(key: String, label: String): String {
        val v = !prefs.getBoolean(key, false)
        prefs.edit().putBoolean(key, v).apply()
        return label + (if (v) " aktif" else " mati") + " (tersimpan sebagai preferensi)"
    }

    private fun stateJson(): String {
        val t = Booster.batteryTempC(this)
        return JSONObject()
            .put("cpu", Sys.cpuPct())
            .put("gpu", Sys.gpuPct())
            .put("fps", fps)
            .put("ram", Booster.ramPercent(this))
            .put("temp", if (t != null) t.toDouble() else -1.0)
            .put("bat", Booster.batteryPercent(this))
            .put("mode", pmode)
            .put("dnd", dndOn)
            .put("eclipse", prefs.getBoolean("rb_eclipse", false))
            .put("bypass", prefs.getBoolean("rb_bypass", false))
            .put("rec", RecorderService.recording)
            .put("mini", mini != null)
            .put("cpuGhz", Sys.cpuGhz())
            .put("gpuMhz", Sys.gpuMhz())
            .put("cross", cross != null)
            .put("keep", prefs.getBoolean("keepmanual", false))
            .put("autolight", Sys.autoLight(this))
            .put("cool", prefs.getBoolean("cool_on", false))
            .put("bright", Sys.brightPct(this) * 255 / 100)
            .put("vol", Sys.volPct(this))
            .put("x", prefs.getBoolean("xmode", false))
            .toString()
    }

    private fun doShot() {
        collapse()
        handler.postDelayed({
            val svc = RbAccessibilityService.inst
            if (svc == null) {
                toast("Aktifkan layanan aksesibilitas R BOOST dulu")
                openActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            } else {
                svc.shoot { ok -> toast(if (ok) "Screenshot tersimpan di Galeri (Pictures/RBoost)" else "Screenshot gagal") }
            }
        }, 700L)
    }

    inner class PanelBridge {
        @JavascriptInterface
        fun state(): String = stateJson()

        @JavascriptInterface
        fun shortcuts(): String {
            val arr = org.json.JSONArray()
            try {
                val pm = packageManager
                val list = ArrayList<String>()
                prefs.getString("last_games", "")?.split(",")?.filter { it.isNotEmpty() }?.let { list.addAll(it) }
                for (pkg in Games.gamePackages(this@OverlayService)) if (pkg !in list) list.add(pkg)
                for (pkg in list.take(5)) {
                    if (pm.getLaunchIntentForPackage(pkg) == null) continue
                    val label = pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
                    arr.put(JSONObject().put("p", pkg).put("n", label).put("i", Games.iconB64(pm.getApplicationIcon(pkg))))
                }
            } catch (_: Exception) {
            }
            return arr.toString()
        }

        @JavascriptInterface
        fun open(pkg: String) {
            handler.post {
                collapse()
                val i = packageManager.getLaunchIntentForPackage(pkg)
                if (i != null) openActivity(i)
            }
        }

        @JavascriptInterface
        fun act(name: String, arg: String): String {
            when (name) {
                "mode" -> {
                    handler.post { setPMode(arg) }
                    return when (arg) {
                        "adv" -> "Advanced: layar tetap menyala, memori dibersihkan tiap 3 menit"
                        "perf" -> "Performance: layar tetap menyala, memori dibersihkan"
                        else -> "Balance: pengaturan normal"
                    }
                }
                "boost" -> {
                    val n = Booster.boost(this@OverlayService, setOfNotNull(gamePkg))
                    return "Menutup $n app di background"
                }
                "dnd" -> {
                    if (!nm().isNotificationPolicyAccessGranted) {
                        handler.post { collapse(); openActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
                        return "!Izinkan akses Jangan Ganggu untuk R BOOST dulu"
                    }
                    setDnd(!dndOn)
                    return if (dndOn) "Jangan Ganggu aktif" else "Jangan Ganggu mati"
                }
                "eclipse" -> return togglePref("rb_eclipse", "Eclipse Touch")
                "bypass" -> return togglePref("rb_bypass", "Bypass Charging")
                "shot" -> {
                    handler.post { doShot() }
                    return ""
                }
                "rec" -> {
                    if (RecorderService.recording) {
                        startService(Intent(this@OverlayService, RecorderService::class.java).setAction(RecorderService.ACTION_STOP))
                        return "Rekaman dihentikan"
                    }
                    handler.post { collapse(); openActivity(Intent(this@OverlayService, CaptureActivity::class.java)) }
                    return ""
                }
                "wm" -> {
                    val willOn = mini == null
                    handler.post { toggleMini() }
                    return if (willOn) "Mini monitor aktif" else "Mini monitor mati"
                }
                "cross" -> {
                    val willOn = cross == null
                    handler.post { if (willOn) showCross() else removeCross() }
                    return if (willOn) "Crosshair aktif" else "Crosshair mati"
                }
                "wifi" -> {
                    handler.post { collapse(); openActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) }
                    return ""
                }
                "autolight" -> {
                    if (!Settings.System.canWrite(this@OverlayService)) return "!Izinkan 'Ubah pengaturan sistem' dulu di R BOOST"
                    val on = !Sys.autoLight(this@OverlayService)
                    Sys.setAutoLight(this@OverlayService, on)
                    return if (on) "Cahaya otomatis aktif" else "Cahaya otomatis mati"
                }
                "keep" -> {
                    val v = !prefs.getBoolean("keepmanual", false)
                    prefs.edit().putBoolean("keepmanual", v).apply()
                    keepOn = v || pmode != "bal"
                    handler.post { applyKeepOn() }
                    return if (v) "Layar tetap menyala" else "Layar boleh mati"
                }
                "cool" -> {
                    val on = !prefs.getBoolean("cool_on", false)
                    Thread { Sys.cooling(this@OverlayService, on) }.start()
                    return if (on) "Cooling aktif: app background ditutup, layar diredupkan" else "Cooling mati"
                }
                "bright" -> {
                    val pct = (arg.toIntOrNull() ?: 50).coerceIn(1, 100)
                    if (!Sys.setBright(this@OverlayService, pct)) return "!Izinkan 'Ubah pengaturan sistem' dulu"
                    return ""
                }
                "vol" -> {
                    Sys.setVol(this@OverlayService, (arg.toIntOrNull() ?: 50).coerceIn(0, 100))
                    return ""
                }
                "home" -> {
                    handler.post { collapse(); openActivity(Intent(this@OverlayService, MainActivity::class.java)) }
                    return ""
                }
                "xexit" -> {
                    prefs.edit().putBoolean("xmode", false).apply()
                    handler.post { collapse() }
                    return "Mode X ESPORT dimatikan"
                }
                "power" -> {
                    handler.post { stopSelf() }
                    return ""
                }
                "close" -> {
                    handler.post { collapse() }
                    return ""
                }
            }
            return ""
        }
    }

    companion object {
        const val ACTION_STOP = "com.gameturbo.app.STOP"
        const val ACTION_MINI = "com.gameturbo.app.MINI"
        const val ACTION_INTRO = "com.gameturbo.app.INTRO"
        const val EXTRA_GAME = "game"
        private const val NOTIF_ID = 2001

        @Volatile
        var running = false

        fun start(ctx: Context, gamePkg: String?) {
            val i = Intent(ctx, OverlayService::class.java)
            if (gamePkg != null) i.putExtra(EXTRA_GAME, gamePkg)
            ContextCompat.startForegroundService(ctx, i)
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, OverlayService::class.java))
        }
    }
}
